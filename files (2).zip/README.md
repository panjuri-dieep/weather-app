# Skyline Weather

A responsive weather app built with vanilla HTML, CSS, and JavaScript. Search any city, or use your location, to see current conditions and a 5-day forecast.

**Live demo:** https://YOUR-USERNAME.github.io/weather-app/

## Features
- City search with geocoding
- "Use my location" (browser Geolocation API)
- Current temperature, feels-like, humidity, and wind
- 5-day forecast
- °C / °F toggle
- Background colour changes with the weather and time of day
- Remembers your last city and unit (localStorage)
- Loading and error states, keyboard accessible, mobile friendly

## Tech stack
- HTML5, CSS3 (custom properties, grid, flexbox)
- JavaScript (ES6+, async/await, Fetch API)
- [Open-Meteo API](https://open-meteo.com/) (free, no API key required)

## Run locally
```bash
git clone https://github.com/YOUR-USERNAME/weather-app.git
cd weather-app
# open index.html in your browser, or:
python -m http.server 8000
```

## What I learned
- Working with REST APIs and handling async errors
- Chaining two API calls (geocoding, then forecast)
- Persisting user preferences with localStorage
- Deploying a static site with GitHub Pages

## Ideas for improvement
- Hourly forecast chart
- Air quality index
- Search suggestions as you type
- Dark/light mode toggle
